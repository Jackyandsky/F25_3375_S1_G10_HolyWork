import axios from 'axios';
import { API_BASE_URL, API_ENDPOINTS } from './config';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Survey Service
const surveyService = {
  /**
   * Submit a new survey response
   * @param {Object} surveyData - Complete survey data
   * @returns {Promise} API response
   */
  submitSurvey: async (surveyData) => {
    try {
      const response = await api.post(API_ENDPOINTS.SURVEYS, surveyData);
      return response.data;
    } catch (error) {
      console.error('Error submitting survey:', error);
      throw error;
    }
  },

  /**
   * Get all survey responses
   * @returns {Promise} API response with all surveys
   */
  getAllSurveys: async () => {
    try {
      const response = await api.get(API_ENDPOINTS.SURVEYS);
      return response.data;
    } catch (error) {
      console.error('Error fetching surveys:', error);
      throw error;
    }
  },

  /**
   * Get survey by ID
   * @param {number} id - Survey/Respondent ID
   * @returns {Promise} API response with survey data
   */
  getSurveyById: async (id) => {
    try {
      const response = await api.get(`${API_ENDPOINTS.SURVEYS}/${id}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching survey:', error);
      throw error;
    }
  },

  /**
   * Get survey statistics
   * @returns {Promise} API response with statistics
   */
  getStatistics: async () => {
    try {
      const response = await api.get(API_ENDPOINTS.STATISTICS);
      return response.data;
    } catch (error) {
      console.error('Error fetching statistics:', error);
      throw error;
    }
  },

  /**
   * Get youth responses (18-35 age group)
   * @returns {Promise} API response with youth data
   */
  getYouthResponses: async () => {
    try {
      const response = await api.get(API_ENDPOINTS.YOUTH);
      return response.data;
    } catch (error) {
      console.error('Error fetching youth responses:', error);
      throw error;
    }
  },

  /**
   * Delete a survey response
   * @param {number} id - Survey/Respondent ID
   * @returns {Promise} API response
   */
  deleteSurvey: async (id) => {
    try {
      const response = await api.delete(`${API_ENDPOINTS.SURVEYS}/${id}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting survey:', error);
      throw error;
    }
  },
};

export default surveyService;
