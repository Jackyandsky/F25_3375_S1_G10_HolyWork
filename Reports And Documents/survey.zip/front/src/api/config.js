// API Configuration
export const API_BASE_URL = process.env.REACT_APP_API_URL || 'https://surveyapi.quizmk.com/api';

export const API_ENDPOINTS = {
  SURVEYS: '/surveys',
  STATISTICS: '/surveys/statistics',
  YOUTH: '/surveys/youth',
};
