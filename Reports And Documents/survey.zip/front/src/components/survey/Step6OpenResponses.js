import React from 'react';
import { Label } from '../ui/label';
import { Input } from '../ui/input';
import { Checkbox } from '../ui/checkbox';
import { MessageSquare, ShieldAlert, Lightbulb, Sparkles } from 'lucide-react';

function Step6OpenResponses({ data, updateData }) {
  const handleCheckboxGroup = (fieldName, value) => {
    const current = data[fieldName] || [];
    const updated = current.includes(value)
      ? current.filter(item => item !== value)
      : [...current, value];
    updateData({ [fieldName]: updated });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-gray-900">Your Feedback</h2>
        <p className="text-sm text-gray-600">
          Finally, we'd love to hear your thoughts. Please select the options that best represent your views.
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <Label className="flex items-center gap-2 text-base">
            <MessageSquare className="h-4 w-4" />
            What are the top features you would want in a church management app?
          </Label>
          <p className="text-sm text-gray-600">Select all that apply</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              'Easy volunteer scheduling',
              'Automated reminders and notifications',
              'Calendar integration',
              'Team communication tools',
              'Event management',
              'Digital service bulletin',
              'Prayer request sharing',
              'Bible study resources',
              'Attendance tracking',
              'Ministry team coordination'
            ].map(feature => (
              <div key={feature} className="flex items-center space-x-2">
                <Checkbox
                  id={`top-feature-${feature}`}
                  checked={(data.topFeatures || []).includes(feature)}
                  onCheckedChange={() => handleCheckboxGroup('topFeatures', feature)}
                />
                <label
                  htmlFor={`top-feature-${feature}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {feature}
                </label>
              </div>
            ))}
          </div>
          <div className="space-y-2 pl-4 border-l-2 border-gray-200">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="top-features-other-toggle"
                checked={data.topFeaturesOther !== undefined && data.topFeaturesOther !== ''}
                onCheckedChange={(checked) => {
                  if (checked) {
                    updateData({ topFeaturesOther: ' ' });
                  } else {
                    updateData({ topFeaturesOther: '' });
                  }
                }}
              />
              <label
                htmlFor="top-features-other-toggle"
                className="text-sm font-medium leading-none cursor-pointer"
              >
                Other (please specify)
              </label>
            </div>
            {(data.topFeaturesOther !== undefined && data.topFeaturesOther !== '') && (
              <Input
                className="ml-6"
                placeholder="Please describe other features..."
                value={(data.topFeaturesOther || '').trim()}
                onChange={(e) => updateData({ topFeaturesOther: e.target.value })}
              />
            )}
          </div>
        </div>

        <div className="space-y-3">
          <Label className="flex items-center gap-2 text-base">
            <ShieldAlert className="h-4 w-4" />
            What are your main concerns about using mobile apps for church activities?
          </Label>
          <p className="text-sm text-gray-600">Select all that apply</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              'Privacy and data security',
              'Distractions during worship',
              'Technology barriers for older members',
              'Cost or subscription fees',
              'Learning curve for new technology',
              'Losing personal connections',
              'Over-reliance on technology',
              'Screen time concerns',
              'Internet connectivity issues',
              'No major concerns'
            ].map(concern => (
              <div key={concern} className="flex items-center space-x-2">
                <Checkbox
                  id={`main-concern-${concern}`}
                  checked={(data.mainConcerns || []).includes(concern)}
                  onCheckedChange={() => handleCheckboxGroup('mainConcerns', concern)}
                />
                <label
                  htmlFor={`main-concern-${concern}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {concern}
                </label>
              </div>
            ))}
          </div>
          <div className="space-y-2 pl-4 border-l-2 border-gray-200">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="main-concerns-other-toggle"
                checked={data.mainConcernsOther !== undefined && data.mainConcernsOther !== ''}
                onCheckedChange={(checked) => {
                  if (checked) {
                    updateData({ mainConcernsOther: ' ' });
                  } else {
                    updateData({ mainConcernsOther: '' });
                  }
                }}
              />
              <label
                htmlFor="main-concerns-other-toggle"
                className="text-sm font-medium leading-none cursor-pointer"
              >
                Other (please specify)
              </label>
            </div>
            {(data.mainConcernsOther !== undefined && data.mainConcernsOther !== '') && (
              <Input
                className="ml-6"
                placeholder="Please describe other concerns..."
                value={(data.mainConcernsOther || '').trim()}
                onChange={(e) => updateData({ mainConcernsOther: e.target.value })}
              />
            )}
          </div>
        </div>

        <div className="space-y-3">
          <Label className="flex items-center gap-2 text-base">
            <Lightbulb className="h-4 w-4" />
            How would this app improve your church experience?
          </Label>
          <p className="text-sm text-gray-600">Select all that apply</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              'Better organization and planning',
              'Easier to stay informed',
              'More time for ministry',
              'Reduced scheduling conflicts',
              'Improved communication',
              'Easier to serve and volunteer',
              'Stronger community connections',
              'More consistent reminders',
              'Simplified administrative tasks',
              'Better work-life balance'
            ].map(improvement => (
              <div key={improvement} className="flex items-center space-x-2">
                <Checkbox
                  id={`improvement-${improvement}`}
                  checked={(data.improvementIdeas || []).includes(improvement)}
                  onCheckedChange={() => handleCheckboxGroup('improvementIdeas', improvement)}
                />
                <label
                  htmlFor={`improvement-${improvement}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {improvement}
                </label>
              </div>
            ))}
          </div>
          <div className="space-y-2 pl-4 border-l-2 border-gray-200">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="improvement-other-toggle"
                checked={data.improvementIdeasOther !== undefined && data.improvementIdeasOther !== ''}
                onCheckedChange={(checked) => {
                  if (checked) {
                    updateData({ improvementIdeasOther: ' ' });
                  } else {
                    updateData({ improvementIdeasOther: '' });
                  }
                }}
              />
              <label
                htmlFor="improvement-other-toggle"
                className="text-sm font-medium leading-none cursor-pointer"
              >
                Other (please specify)
              </label>
            </div>
            {(data.improvementIdeasOther !== undefined && data.improvementIdeasOther !== '') && (
              <Input
                className="ml-6"
                placeholder="Please describe other improvements..."
                value={(data.improvementIdeasOther || '').trim()}
                onChange={(e) => updateData({ improvementIdeasOther: e.target.value })}
              />
            )}
          </div>
        </div>

        <div className="space-y-3">
          <Label className="flex items-center gap-2 text-base">
            <Sparkles className="h-4 w-4" />
            Any other suggestions, ideas, or feedback?
          </Label>
          <p className="text-sm text-gray-600">Select all that apply</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              'Would like training or tutorials',
              'Need multi-language support',
              'Want integration with existing tools',
              'Prefer offline functionality',
              'Desktop version needed',
              'Would pay for premium features',
              'Interested in beta testing',
              'Want customization options',
              'Need technical support',
              'No additional feedback'
            ].map(feedback => (
              <div key={feedback} className="flex items-center space-x-2">
                <Checkbox
                  id={`additional-${feedback}`}
                  checked={(data.additionalFeedback || []).includes(feedback)}
                  onCheckedChange={() => handleCheckboxGroup('additionalFeedback', feedback)}
                />
                <label
                  htmlFor={`additional-${feedback}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {feedback}
                </label>
              </div>
            ))}
          </div>
          <div className="space-y-2 pl-4 border-l-2 border-gray-200">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="additional-other-toggle"
                checked={data.additionalFeedbackOther !== undefined && data.additionalFeedbackOther !== ''}
                onCheckedChange={(checked) => {
                  if (checked) {
                    updateData({ additionalFeedbackOther: ' ' });
                  } else {
                    updateData({ additionalFeedbackOther: '' });
                  }
                }}
              />
              <label
                htmlFor="additional-other-toggle"
                className="text-sm font-medium leading-none cursor-pointer"
              >
                Other (please specify)
              </label>
            </div>
            {(data.additionalFeedbackOther !== undefined && data.additionalFeedbackOther !== '') && (
              <Input
                className="ml-6"
                placeholder="Please share any other thoughts..."
                value={(data.additionalFeedbackOther || '').trim()}
                onChange={(e) => updateData({ additionalFeedbackOther: e.target.value })}
              />
            )}
          </div>
        </div>

        <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
          <div className="space-y-3 text-center">
            <div className="text-4xl">✨</div>
            <p className="text-base font-medium text-gray-900">
              Thank you for taking the time to complete this survey!
            </p>
            <p className="text-sm text-gray-600">
              Your insights will directly shape the development of GraceFlow.
            </p>
            <p className="text-sm text-gray-600">
              Click "Submit Survey" below to finish.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Step6OpenResponses;
