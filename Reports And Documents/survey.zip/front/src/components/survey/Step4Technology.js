import React from 'react';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';
import { Slider } from '../ui/slider';
import { Smartphone, Gauge } from 'lucide-react';
import { cn } from '../../lib/utils';

function Step4Technology({ data, updateData }) {
  const handleSelectChange = (name, value) => {
    updateData({ [name]: value });
  };

  const handleCheckboxGroup = (fieldName, value) => {
    const current = data[fieldName] || [];
    const updated = current.includes(value)
      ? current.filter(item => item !== value)
      : [...current, value];
    updateData({ [fieldName]: updated });
  };

  const handleRating = (rating) => {
    updateData({ appComfortLevel: rating });
  };

  const socialMediaOptions = [
    'Instagram',
    'TikTok',
    'Facebook',
    'Twitter/X',
    'YouTube',
    'None',
    'Other'
  ];

  const churchAppOptions = [
    'Planning Center',
    'Church Center',
    'Subsplash',
    'Breeze',
    'None',
    'Other'
  ];

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-gray-900">Technology Usage</h2>
        <p className="text-sm text-gray-600">
          Help us understand your comfort level with technology and mobile apps.
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="smartphoneType" className="flex items-center gap-2">
            <Smartphone className="h-4 w-4" />
            What type of smartphone do you use?
          </Label>
          <Select value={data.smartphoneType || ''} onValueChange={(value) => handleSelectChange('smartphoneType', value)}>
            <SelectTrigger id="smartphoneType">
              <SelectValue placeholder="Select smartphone type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Android">Android</SelectItem>
              <SelectItem value="iOS">iOS (iPhone)</SelectItem>
              <SelectItem value="Both">Both Android and iOS</SelectItem>
              <SelectItem value="None">I don't use a smartphone</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <Label className="flex items-center gap-2">
            <Gauge className="h-4 w-4" />
            How comfortable are you with mobile apps?
          </Label>
          <p className="text-sm text-gray-600">1 = Not comfortable, 5 = Very comfortable</p>
          <div className="flex gap-2 justify-start">
            {[1, 2, 3, 4, 5].map(rating => (
              <button
                key={rating}
                type="button"
                className={cn(
                  "w-12 h-12 rounded-lg border-2 font-semibold transition-all",
                  data.appComfortLevel === rating
                    ? "bg-primary text-primary-foreground border-primary shadow-md"
                    : "bg-background border-input hover:border-primary hover:bg-accent"
                )}
                onClick={() => handleRating(rating)}
              >
                {rating}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <Label className="text-base">Which social media platforms do you use?</Label>
          <p className="text-sm text-gray-600">Select all that apply</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {socialMediaOptions.map(option => (
              <div key={option} className="flex items-center space-x-2">
                <Checkbox
                  id={`social-${option}`}
                  checked={(data.socialMediaPlatforms || []).includes(option)}
                  onCheckedChange={() => handleCheckboxGroup('socialMediaPlatforms', option)}
                />
                <label
                  htmlFor={`social-${option}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {option}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <Label className="text-base">Do you currently use any church-related apps?</Label>
          <p className="text-sm text-gray-600">Select all that apply</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {churchAppOptions.map(option => (
              <div key={option} className="flex items-center space-x-2">
                <Checkbox
                  id={`app-${option}`}
                  checked={(data.currentChurchApps || []).includes(option)}
                  onCheckedChange={() => handleCheckboxGroup('currentChurchApps', option)}
                />
                <label
                  htmlFor={`app-${option}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {option}
                </label>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Step4Technology;
