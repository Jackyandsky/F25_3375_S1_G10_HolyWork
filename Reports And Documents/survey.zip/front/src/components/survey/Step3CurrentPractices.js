import React from 'react';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';
import { ClipboardList, Users, AlertCircle } from 'lucide-react';

function Step3CurrentPractices({ data, updateData }) {
  const handleChange = (e) => {
    const { name, value } = e.target;
    updateData({ [name]: value });
  };

  const handleSelectChange = (name, value) => {
    updateData({ [name]: value });
  };

  const handleCheckboxGroup = (fieldName, value) => {
    const current = data[fieldName] || [];
    const updated = current.includes(value)
      ? current.filter(item => item !== value)
      : [...current, value];
    updateData({ [fieldName]: updated });
  };

  const schedulingOptions = [
    'Paper sign-up sheet',
    'Verbal announcement',
    'Phone calls',
    'Email',
    'Text messages (SMS)',
    'WhatsApp',
    'Facebook Messenger',
    'Mobile phone app',
    'Website / Web application',
    'Google Sheets / Spreadsheet',
    'Calendar invites',
    'Bulletin board',
    'Group meetings',
    'No formal system'
  ];

  const volunteerTeamOptions = [
    'Setup / Preparation Team',
    'Cleanup / Maintenance Team',
    'Worship / Music Team',
    'Hospitality / Welcome Team',
    'Sanctuary Care Team',
    'Children\'s Ministry',
    'Youth Ministry',
    'Prayer Team',
    'Usher / Greeter Team',
    'Audio/Visual Team',
    'Communion Servers',
    'Teaching / Bible Study Leaders',
    'Administrative Support',
    'Outreach / Community Service'
  ];

  const [showSchedulingOther, setShowSchedulingOther] = React.useState(false);
  const [showTeamsOther, setShowTeamsOther] = React.useState(false);
  const [schedulingOther, setSchedulingOther] = React.useState('');
  const [teamsOther, setTeamsOther] = React.useState('');

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-gray-900">Current Practices</h2>
        <p className="text-sm text-gray-600">
          Help us understand how your church currently manages volunteers and scheduling.
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <Label className="flex items-center gap-2 text-base">
            <ClipboardList className="h-4 w-4" />
            Current Scheduling Methods
          </Label>
          <p className="text-sm text-gray-600">How does your church currently coordinate volunteers? Select all that apply</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {schedulingOptions.map(option => (
              <div key={option} className="flex items-center space-x-2">
                <Checkbox
                  id={`scheduling-${option}`}
                  checked={(data.schedulingMethods || []).includes(option)}
                  onCheckedChange={() => handleCheckboxGroup('schedulingMethods', option)}
                />
                <label
                  htmlFor={`scheduling-${option}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {option}
                </label>
              </div>
            ))}
          </div>
          <div className="space-y-2 pl-4 border-l-2 border-gray-200">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="scheduling-other-toggle"
                checked={showSchedulingOther}
                onCheckedChange={(checked) => {
                  setShowSchedulingOther(checked);
                  if (!checked) {
                    setSchedulingOther('');
                    const filtered = (data.schedulingMethods || []).filter(m => !m.startsWith('Other:'));
                    updateData({ schedulingMethods: filtered });
                  }
                }}
              />
              <label
                htmlFor="scheduling-other-toggle"
                className="text-sm font-medium leading-none cursor-pointer"
              >
                Other (please specify)
              </label>
            </div>
            {showSchedulingOther && (
              <Input
                className="ml-6"
                placeholder="Please describe..."
                value={schedulingOther}
                onChange={(e) => {
                  setSchedulingOther(e.target.value);
                  const filtered = (data.schedulingMethods || []).filter(m => !m.startsWith('Other:'));
                  if (e.target.value.trim()) {
                    updateData({ schedulingMethods: [...filtered, `Other: ${e.target.value}`] });
                  } else {
                    updateData({ schedulingMethods: filtered });
                  }
                }}
              />
            )}
          </div>
        </div>

        <div className="space-y-3">
          <Label className="flex items-center gap-2 text-base">
            <Users className="h-4 w-4" />
            Ministry Teams & Volunteer Roles
          </Label>
          <p className="text-sm text-gray-600">Which teams or ministries do you serve in? Select all that apply</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {volunteerTeamOptions.map(option => (
              <div key={option} className="flex items-center space-x-2">
                <Checkbox
                  id={`team-${option}`}
                  checked={(data.volunteerTeams || []).includes(option)}
                  onCheckedChange={() => handleCheckboxGroup('volunteerTeams', option)}
                />
                <label
                  htmlFor={`team-${option}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {option}
                </label>
              </div>
            ))}
          </div>
          <div className="space-y-2 pl-4 border-l-2 border-gray-200">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="teams-other-toggle"
                checked={showTeamsOther}
                onCheckedChange={(checked) => {
                  setShowTeamsOther(checked);
                  if (!checked) {
                    setTeamsOther('');
                    const filtered = (data.volunteerTeams || []).filter(t => !t.startsWith('Other:'));
                    updateData({ volunteerTeams: filtered });
                  }
                }}
              />
              <label
                htmlFor="teams-other-toggle"
                className="text-sm font-medium leading-none cursor-pointer"
              >
                Other ministry (please specify)
              </label>
            </div>
            {showTeamsOther && (
              <Input
                className="ml-6"
                placeholder="Please describe your ministry role..."
                value={teamsOther}
                onChange={(e) => {
                  setTeamsOther(e.target.value);
                  const filtered = (data.volunteerTeams || []).filter(t => !t.startsWith('Other:'));
                  if (e.target.value.trim()) {
                    updateData({ volunteerTeams: [...filtered, `Other: ${e.target.value}`] });
                  } else {
                    updateData({ volunteerTeams: filtered });
                  }
                }}
              />
            )}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="volunteerFrequency">
            How Often Do You Volunteer?
          </Label>
          <Select value={data.volunteerFrequency || ''} onValueChange={(value) => handleSelectChange('volunteerFrequency', value)}>
            <SelectTrigger id="volunteerFrequency">
              <SelectValue placeholder="Select frequency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Weekly">Weekly</SelectItem>
              <SelectItem value="Bi-weekly">Bi-weekly (Every 2 weeks)</SelectItem>
              <SelectItem value="Monthly">Monthly</SelectItem>
              <SelectItem value="Occasionally">Occasionally</SelectItem>
              <SelectItem value="Never">I don't volunteer currently</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <Label className="flex items-center gap-2 text-base">
            <AlertCircle className="h-4 w-4" />
            Current Challenges
          </Label>
          <p className="text-sm text-gray-600">
            What difficulties do you face with current scheduling and volunteer management? Select all that apply
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              'Hard to coordinate schedules',
              'Last-minute changes are difficult',
              'Forget when I\'m scheduled',
              'Communication gaps between team members',
              'No central system for tracking',
              'Time-consuming manual process',
              'Difficult to find replacements',
              'Lack of reminders/notifications',
              'Poor visibility of who is serving',
              'Conflicts with personal schedule'
            ].map(challenge => (
              <div key={challenge} className="flex items-center space-x-2">
                <Checkbox
                  id={`challenge-${challenge}`}
                  checked={(data.currentChallenges || []).includes(challenge)}
                  onCheckedChange={() => handleCheckboxGroup('currentChallenges', challenge)}
                />
                <label
                  htmlFor={`challenge-${challenge}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {challenge}
                </label>
              </div>
            ))}
          </div>
          <div className="space-y-2 pl-4 border-l-2 border-gray-200">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="challenges-other-toggle"
                checked={data.currentChallengesOther !== undefined && data.currentChallengesOther !== ''}
                onCheckedChange={(checked) => {
                  if (checked) {
                    updateData({ currentChallengesOther: ' ' });
                  } else {
                    updateData({ currentChallengesOther: '' });
                  }
                }}
              />
              <label
                htmlFor="challenges-other-toggle"
                className="text-sm font-medium leading-none cursor-pointer"
              >
                Other (please specify)
              </label>
            </div>
            {(data.currentChallengesOther !== undefined && data.currentChallengesOther !== '') && (
              <Input
                className="ml-6"
                placeholder="Please describe other challenges..."
                value={(data.currentChallengesOther || '').trim()}
                onChange={(e) => updateData({ currentChallengesOther: e.target.value })}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Step3CurrentPractices;
