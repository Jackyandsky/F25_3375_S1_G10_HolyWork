import React from 'react';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Church, MapPin, Users, Calendar } from 'lucide-react';

function Step2ChurchInfo({ data, updateData }) {
  const handleChange = (e) => {
    const { name, value } = e.target;
    updateData({ [name]: value });
  };

  const handleSelectChange = (name, value) => {
    updateData({ [name]: value });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-gray-900">Church Information</h2>
        <p className="text-sm text-gray-600">
          Tell us about your church or organization.
        </p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="churchName" className="flex items-center gap-2">
            <Church className="h-4 w-4" />
            Church / Organization Name
          </Label>
          <Input
            type="text"
            id="churchName"
            name="churchName"
            value={data.churchName || ''}
            onChange={handleChange}
            placeholder="e.g., Grace Community Church"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="churchType">
            Church Type / Denomination
          </Label>
          <Select value={data.churchType || ''} onValueChange={(value) => handleSelectChange('churchType', value)}>
            <SelectTrigger id="churchType">
              <SelectValue placeholder="Select church type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Protestant">Protestant</SelectItem>
              <SelectItem value="Catholic">Catholic</SelectItem>
              <SelectItem value="Non-denominational">Non-denominational</SelectItem>
              <SelectItem value="Community Church">Community Church</SelectItem>
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="churchScale" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Church Size
          </Label>
          <Select value={data.churchScale || ''} onValueChange={(value) => handleSelectChange('churchScale', value)}>
            <SelectTrigger id="churchScale">
              <SelectValue placeholder="Select church size" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Small (<50)">Small (Less than 50 members)</SelectItem>
              <SelectItem value="Medium (50-200)">Medium (50-200 members)</SelectItem>
              <SelectItem value="Large (200-500)">Large (200-500 members)</SelectItem>
              <SelectItem value="Very Large (500+)">Very Large (500+ members)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="averageWorshipers">
              Average Weekly Attendance
            </Label>
            <Input
              type="number"
              id="averageWorshipers"
              name="averageWorshipers"
              value={data.averageWorshipers || ''}
              onChange={handleChange}
              placeholder="e.g., 150"
              min="0"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="yearsAtChurch" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Years at This Church
            </Label>
            <Input
              type="number"
              id="yearsAtChurch"
              name="yearsAtChurch"
              value={data.yearsAtChurch || ''}
              onChange={handleChange}
              placeholder="e.g., 5"
              min="0"
              max="100"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="location" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Location (City, Region)
          </Label>
          <Input
            type="text"
            id="location"
            name="location"
            value={data.location || ''}
            onChange={handleChange}
            placeholder="e.g., Vancouver, BC"
          />
        </div>
      </div>
    </div>
  );
}

export default Step2ChurchInfo;
