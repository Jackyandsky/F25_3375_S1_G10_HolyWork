import React from 'react';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';
import { Input } from '../ui/input';
import { Star, MapPin, Sparkles, BookOpen } from 'lucide-react';
import { cn } from '../../lib/utils';

function Step5FeatureRatings({
  featureRatings,
  crossChurchInterest,
  youthEngagement,
  bibleStudy,
  updateFeatureRatings,
  updateCrossChurch,
  updateYouthEngagement,
  updateBibleStudy,
  age
}) {
  const handleRating = (feature, rating) => {
    updateFeatureRatings({ [feature]: rating });
  };

  const handleYouthRating = (field, rating) => {
    updateYouthEngagement({ [field]: rating });
  };

  const handleChange = (updateFunc) => (e) => {
    const { name, value, type, checked } = e.target;
    updateFunc({ [name]: type === 'checkbox' ? checked : value });
  };

  const handleSelectChange = (updateFunc, name, value) => {
    updateFunc({ [name]: value });
  };

  const isYouth = age && (age >= 18 && age <= 35);

  const features = [
    { key: 'automatedScheduling', label: 'Automated Scheduling with Reminders' },
    { key: 'crossChurchCalendar', label: 'Cross-Church Volunteer Calendar' },
    { key: 'serviceAgendaBuilder', label: 'Service Agenda Builder' },
    { key: 'digitalServiceBook', label: 'Digital Service Book' },
    { key: 'communityPrayerWall', label: 'Community Prayer Wall' },
    { key: 'gamification', label: 'Gamification (badges, leaderboards)' },
    { key: 'socialSharing', label: 'Social Sharing Features' },
    { key: 'bibleStudyTools', label: 'Bible Study Tools' },
    { key: 'pushNotifications', label: 'Push Notifications' }
  ];

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-gray-900">Feature Ratings & Preferences</h2>
        <p className="text-sm text-gray-600">
          Rate how valuable these proposed features would be for you.
          1 = Not valuable, 5 = Extremely valuable
        </p>
      </div>

      {/* Feature Ratings */}
      <div className="space-y-5">
        {features.map(feature => (
          <div key={feature.key} className="space-y-2">
            <Label className="flex items-center gap-2">
              <Star className="h-4 w-4" />
              {feature.label}
            </Label>
            <div className="flex gap-2 justify-start">
              {[1, 2, 3, 4, 5].map(rating => (
                <button
                  key={rating}
                  type="button"
                  className={cn(
                    "w-12 h-12 rounded-lg border-2 font-semibold transition-all",
                    featureRatings[feature.key] === rating
                      ? "bg-primary text-primary-foreground border-primary shadow-md"
                      : "bg-background border-input hover:border-primary hover:bg-accent"
                  )}
                  onClick={() => handleRating(feature.key, rating)}
                >
                  {rating}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Cross-Church Interest */}
      <div className="border-t pt-6 mt-6">
        <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2 mb-4">
          <MapPin className="h-5 w-5" />
          Cross-Church Volunteering
        </h3>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Would you be interested in volunteering at other nearby churches?</Label>
            <Select
              value={crossChurchInterest.interested === null ? '' : String(crossChurchInterest.interested)}
              onValueChange={(value) => handleSelectChange(updateCrossChurch, 'interested', value === 'true')}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select an option" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="true">Yes, I'd be interested</SelectItem>
                <SelectItem value="false">No, not interested</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {crossChurchInterest.interested && (
            <div className="space-y-2">
              <Label htmlFor="willingDistance">
                How far would you be willing to travel?
              </Label>
              <Select
                value={crossChurchInterest.willingDistance || ''}
                onValueChange={(value) => handleSelectChange(updateCrossChurch, 'willingDistance', value)}
              >
                <SelectTrigger id="willingDistance">
                  <SelectValue placeholder="Select distance" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Same church only">Same church only</SelectItem>
                  <SelectItem value="<5 miles">Less than 5 miles</SelectItem>
                  <SelectItem value="<10 miles">Less than 10 miles</SelectItem>
                  <SelectItem value="<20 miles">Less than 20 miles</SelectItem>
                  <SelectItem value="Anywhere in region">Anywhere in the region</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
      </div>

      {/* Youth Engagement (if applicable) */}
      {isYouth && (
        <div className="border-t pt-6 mt-6">
          <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2 mb-4">
            <Sparkles className="h-5 w-5" />
            Youth Engagement (Ages 18-35)
          </h3>

          <div className="space-y-5">
            <div className="space-y-2">
              <Label>How interested are you in social features (stories, posts, sharing)?</Label>
              <div className="flex gap-2 justify-start">
                {[1, 2, 3, 4, 5].map(rating => (
                  <button
                    key={rating}
                    type="button"
                    className={cn(
                      "w-12 h-12 rounded-lg border-2 font-semibold transition-all",
                      youthEngagement.socialFeaturesInterest === rating
                        ? "bg-primary text-primary-foreground border-primary shadow-md"
                        : "bg-background border-input hover:border-primary hover:bg-accent"
                    )}
                    onClick={() => handleYouthRating('socialFeaturesInterest', rating)}
                  >
                    {rating}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>How appealing is gamification (badges, streaks, leaderboards)?</Label>
              <div className="flex gap-2 justify-start">
                {[1, 2, 3, 4, 5].map(rating => (
                  <button
                    key={rating}
                    type="button"
                    className={cn(
                      "w-12 h-12 rounded-lg border-2 font-semibold transition-all",
                      youthEngagement.gamificationAppeal === rating
                        ? "bg-primary text-primary-foreground border-primary shadow-md"
                        : "bg-background border-input hover:border-primary hover:bg-accent"
                    )}
                    onClick={() => handleYouthRating('gamificationAppeal', rating)}
                  >
                    {rating}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="preferredRecognition">
                How would you prefer to be recognized for volunteering?
              </Label>
              <Select
                value={youthEngagement.preferredRecognition || ''}
                onValueChange={(value) => handleSelectChange(updateYouthEngagement, 'preferredRecognition', value)}
              >
                <SelectTrigger id="preferredRecognition">
                  <SelectValue placeholder="Select preference" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Public recognition">Public recognition</SelectItem>
                  <SelectItem value="Private thank you">Private thank you</SelectItem>
                  <SelectItem value="Badges/points">Badges and points</SelectItem>
                  <SelectItem value="No preference">No preference</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      )}

      {/* Bible Study */}
      <div className="border-t pt-6 mt-6">
        <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2 mb-4">
          <BookOpen className="h-5 w-5" />
          Bible Study & Faith Sharing
        </h3>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="currentParticipation">
              How often do you participate in Bible study?
            </Label>
            <Select
              value={bibleStudy.currentParticipation || ''}
              onValueChange={(value) => handleSelectChange(updateBibleStudy, 'currentParticipation', value)}
            >
              <SelectTrigger id="currentParticipation">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Weekly">Weekly</SelectItem>
                <SelectItem value="Monthly">Monthly</SelectItem>
                <SelectItem value="Occasionally">Occasionally</SelectItem>
                <SelectItem value="Never">Never</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="digitalToolsInterest"
              checked={bibleStudy.digitalToolsInterest || false}
              onCheckedChange={(checked) => updateBibleStudy({ digitalToolsInterest: checked })}
            />
            <label
              htmlFor="digitalToolsInterest"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
            >
              I'm interested in digital Bible study tools and reading plans
            </label>
          </div>

          <div className="space-y-3">
            <Label className="text-base">Any concerns about digital faith content?</Label>
            <p className="text-sm text-gray-600">Select all that apply</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[
                'Biblical accuracy concerns',
                'Distractions during worship',
                'Technology replacing personal connection',
                'Privacy and data security',
                'Accessibility for older members',
                'Screen time concerns',
                'Loss of traditional practices',
                'No concerns'
              ].map(concern => (
                <div key={concern} className="flex items-center space-x-2">
                  <Checkbox
                    id={`faith-concern-${concern}`}
                    checked={(bibleStudy.faithContentConcerns || []).includes(concern)}
                    onCheckedChange={() => {
                      const current = bibleStudy.faithContentConcerns || [];
                      const updated = current.includes(concern)
                        ? current.filter(item => item !== concern)
                        : [...current, concern];
                      updateBibleStudy({ faithContentConcerns: updated });
                    }}
                  />
                  <label
                    htmlFor={`faith-concern-${concern}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {concern}
                  </label>
                </div>
              ))}
            </div>
            <div className="space-y-2 pl-4 border-l-2 border-gray-200">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="faith-concerns-other-toggle"
                  checked={bibleStudy.faithContentConcernsOther !== undefined && bibleStudy.faithContentConcernsOther !== ''}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      updateBibleStudy({ faithContentConcernsOther: ' ' });
                    } else {
                      updateBibleStudy({ faithContentConcernsOther: '' });
                    }
                  }}
                />
                <label
                  htmlFor="faith-concerns-other-toggle"
                  className="text-sm font-medium leading-none cursor-pointer"
                >
                  Other (please specify)
                </label>
              </div>
              {(bibleStudy.faithContentConcernsOther !== undefined && bibleStudy.faithContentConcernsOther !== '') && (
                <Input
                  className="ml-6"
                  placeholder="Please describe other concerns..."
                  value={(bibleStudy.faithContentConcernsOther || '').trim()}
                  onChange={(e) => updateBibleStudy({ faithContentConcernsOther: e.target.value })}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Step5FeatureRatings;
