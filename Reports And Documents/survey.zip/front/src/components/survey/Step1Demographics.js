import React from 'react';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { User, Mail } from 'lucide-react';

function Step1Demographics({ data, updateData }) {
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    updateData({
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleSelectChange = (name, value) => {
    updateData({ [name]: value });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-gray-900">About You</h2>
        <p className="text-sm text-gray-600">
          Tell us a bit about yourself. You can use an alias or nickname if you prefer.
        </p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Name / Alias / Nickname <span className="text-red-500">*</span>
          </Label>
          <Input
            type="text"
            id="name"
            name="name"
            value={data.name || ''}
            onChange={handleChange}
            placeholder="Your name or alias"
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="age">
              Age (optional)
            </Label>
            <Input
              type="number"
              id="age"
              name="age"
              value={data.age || ''}
              onChange={handleChange}
              placeholder="e.g., 28"
              min="1"
              max="120"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ageRange">
              Age Range <span className="text-red-500">*</span>
            </Label>
            <Select value={data.ageRange || ''} onValueChange={(value) => handleSelectChange('ageRange', value)}>
              <SelectTrigger id="ageRange">
                <SelectValue placeholder="Select age range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="18-25">18-25</SelectItem>
                <SelectItem value="26-35">26-35</SelectItem>
                <SelectItem value="36-50">36-50</SelectItem>
                <SelectItem value="51-65">51-65</SelectItem>
                <SelectItem value="65+">65+</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="gender">
            Gender (optional)
          </Label>
          <Select value={data.gender || ''} onValueChange={(value) => handleSelectChange('gender', value)}>
            <SelectTrigger id="gender">
              <SelectValue placeholder="Select gender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Male">Male</SelectItem>
              <SelectItem value="Female">Female</SelectItem>
              <SelectItem value="Non-binary">Non-binary</SelectItem>
              <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="role">
            Your Role in the Church <span className="text-red-500">*</span>
          </Label>
          <Select value={data.role || ''} onValueChange={(value) => handleSelectChange('role', value)}>
            <SelectTrigger id="role">
              <SelectValue placeholder="Select your role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Church Leader">Church Leader (Pastor, Priest, Minister)</SelectItem>
              <SelectItem value="Church Administrator">Church Administrator / Coordinator</SelectItem>
              <SelectItem value="Worship Leader">Worship Leader / Music Director</SelectItem>
              <SelectItem value="Ministry Leader">Ministry Team Leader</SelectItem>
              <SelectItem value="Active Volunteer">Active Volunteer / Servant</SelectItem>
              <SelectItem value="Regular Member">Regular Member / Attendee</SelectItem>
              <SelectItem value="Youth Member">Youth / Young Adult Member (18-35)</SelectItem>
              <SelectItem value="Senior Member">Senior Member (65+)</SelectItem>
              <SelectItem value="New Member">New Member / Newcomer</SelectItem>
              <SelectItem value="Occasional Attendee">Occasional Attendee</SelectItem>
              <SelectItem value="Parent">Parent / Family Representative</SelectItem>
              <SelectItem value="Other">Other Ministry Role</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="email" className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email Address (Optional)
          </Label>
          <Input
            type="email"
            id="email"
            name="email"
            value={data.email || ''}
            onChange={handleChange}
            placeholder="your.email@example.com"
          />
          <p className="text-xs text-gray-500">
            Your email will only be used for survey-related communication
          </p>
        </div>

        <div className="flex items-center gap-1 text-sm text-gray-600 pt-4 border-t">
          <span className="text-red-500">*</span> Required fields
        </div>
      </div>
    </div>
  );
}

export default Step1Demographics;
