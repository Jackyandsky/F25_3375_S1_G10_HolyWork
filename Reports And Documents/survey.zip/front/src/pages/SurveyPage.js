import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import surveyService from '../api/surveyService';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { Badge } from '../components/ui/badge';
import { Alert, AlertDescription } from '../components/ui/alert';
import { ChevronLeft, ChevronRight, Send } from 'lucide-react';

// Import step components
import Step1Demographics from '../components/survey/Step1Demographics';
import Step2ChurchInfo from '../components/survey/Step2ChurchInfo';
import Step3CurrentPractices from '../components/survey/Step3CurrentPractices';
import Step4Technology from '../components/survey/Step4Technology';
import Step5FeatureRatings from '../components/survey/Step5FeatureRatings';
import Step6OpenResponses from '../components/survey/Step6OpenResponses';

function SurveyPage() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const totalSteps = 6;

  // Form data state
  const [formData, setFormData] = useState({
    // Step 1: Demographics
    respondent: {
      name: '',
      age: '',
      ageRange: '',
      gender: '',
      role: '',
      email: '',
      willingFollowup: false,
    },
    // Step 2: Church Info
    churchInfo: {
      churchName: '',
      churchType: '',
      churchScale: '',
      averageWorshipers: '',
      location: '',
      yearsAtChurch: '',
    },
    // Step 3: Current Practices
    currentPractices: {
      schedulingMethods: [],
      volunteerTeams: [],
      volunteerFrequency: '',
      currentChallenges: '',
    },
    // Step 4: Technology
    technologyUsage: {
      smartphoneType: '',
      appComfortLevel: 3,
      socialMediaPlatforms: [],
      currentChurchApps: [],
    },
    // Step 5: Cross-Church & Features
    crossChurchInterest: {
      interested: null,
      willingDistance: '',
      currentActivities: false,
      activitiesDescription: '',
    },
    featureRatings: {
      automatedScheduling: 3,
      crossChurchCalendar: 3,
      serviceAgendaBuilder: 3,
      digitalServiceBook: 3,
      communityPrayerWall: 3,
      gamification: 3,
      socialSharing: 3,
      bibleStudyTools: 3,
      pushNotifications: 3,
    },
    youthEngagement: {
      socialFeaturesInterest: 3,
      gamificationAppeal: 3,
      digitalSpiritualBalanceConcern: false,
      balanceExplanation: '',
      preferredRecognition: '',
    },
    bibleStudy: {
      currentParticipation: '',
      digitalToolsInterest: false,
      faithContentConcerns: '',
    },
    // Step 6: Open Responses
    openResponses: {
      topFeatures: '',
      mainConcerns: '',
      improvementIdeas: '',
      additionalFeedback: '',
    },
  });

  const updateFormData = (section, data) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        ...data,
      },
    }));
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    setError(null);

    try {
      // Prepare data for submission
      const submitData = {
        ...formData,
        // Convert string numbers to integers
        respondent: {
          ...formData.respondent,
          age: formData.respondent.age ? parseInt(formData.respondent.age) : null,
        },
        churchInfo: {
          ...formData.churchInfo,
          averageWorshipers: formData.churchInfo.averageWorshipers
            ? parseInt(formData.churchInfo.averageWorshipers)
            : null,
          yearsAtChurch: formData.churchInfo.yearsAtChurch
            ? parseInt(formData.churchInfo.yearsAtChurch)
            : null,
        },
      };

      // Submit survey
      await surveyService.submitSurvey(submitData);

      // Navigate to thank you page
      navigate('/thank-you');
    } catch (err) {
      console.error('Submit error:', err);
      setError('Failed to submit survey. Please try again.');
      setSubmitting(false);
    }
  };

  const progress = (currentStep / totalSteps) * 100;

  const stepTitles = [
    'About You',
    'Your Church',
    'Current Practices',
    'Technology Usage',
    'Feature Preferences',
    'Your Feedback'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <Card className="border-purple-200 shadow-xl">
          {/* Header */}
          <CardHeader className="space-y-4 pb-6">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                GraceFlow Survey
              </CardTitle>
              <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                Step {currentStep} of {totalSteps}
              </Badge>
            </div>

            {/* Step Title */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900">{stepTitles[currentStep - 1]}</h2>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <Progress value={progress} className="h-2" />
              <p className="text-sm text-gray-600 text-center">{Math.round(progress)}% Complete</p>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Error Message */}
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Step Content */}
            <div className="min-h-[400px]">
              {currentStep === 1 && (
                <Step1Demographics
                  data={formData.respondent}
                  updateData={(data) => updateFormData('respondent', data)}
                />
              )}
              {currentStep === 2 && (
                <Step2ChurchInfo
                  data={formData.churchInfo}
                  updateData={(data) => updateFormData('churchInfo', data)}
                />
              )}
              {currentStep === 3 && (
                <Step3CurrentPractices
                  data={formData.currentPractices}
                  updateData={(data) => updateFormData('currentPractices', data)}
                />
              )}
              {currentStep === 4 && (
                <Step4Technology
                  data={formData.technologyUsage}
                  updateData={(data) => updateFormData('technologyUsage', data)}
                />
              )}
              {currentStep === 5 && (
                <Step5FeatureRatings
                  featureRatings={formData.featureRatings}
                  crossChurchInterest={formData.crossChurchInterest}
                  youthEngagement={formData.youthEngagement}
                  bibleStudy={formData.bibleStudy}
                  updateFeatureRatings={(data) => updateFormData('featureRatings', data)}
                  updateCrossChurch={(data) => updateFormData('crossChurchInterest', data)}
                  updateYouthEngagement={(data) => updateFormData('youthEngagement', data)}
                  updateBibleStudy={(data) => updateFormData('bibleStudy', data)}
                  age={formData.respondent.age}
                />
              )}
              {currentStep === 6 && (
                <Step6OpenResponses
                  data={formData.openResponses}
                  updateData={(data) => updateFormData('openResponses', data)}
                />
              )}
            </div>

            {/* Navigation Buttons */}
            <div className="flex items-center justify-between pt-6 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 1}
                className="gap-2"
              >
                <ChevronLeft className="w-4 h-4" />
                Previous
              </Button>

              {currentStep < totalSteps ? (
                <Button
                  type="button"
                  onClick={handleNext}
                  className="gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              ) : (
                <Button
                  type="button"
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="gap-2 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                >
                  {submitting ? 'Submitting...' : 'Submit Survey'}
                  <Send className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default SurveyPage;
