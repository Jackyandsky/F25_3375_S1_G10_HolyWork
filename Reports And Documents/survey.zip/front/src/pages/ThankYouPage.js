import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { CheckCircle2, Home, BarChart3, Heart, TrendingUp, Users, Mail } from 'lucide-react';

function ThankYouPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 via-purple-50 to-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <Card className="border-green-200 shadow-xl">
          <CardHeader className="text-center space-y-6 pb-8">
            <div className="flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-green-400 rounded-full blur-xl opacity-50 animate-pulse"></div>
                <div className="relative bg-gradient-to-r from-green-500 to-emerald-500 rounded-full p-6">
                  <CheckCircle2 className="w-16 h-16 text-white" />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                Thank You!
              </h1>
              <p className="text-lg text-gray-700 max-w-2xl mx-auto">
                Your survey response has been submitted successfully. We truly appreciate
                you taking the time to share your thoughts and experiences with us.
              </p>
            </div>
          </CardHeader>

          <CardContent className="space-y-8">
            {/* What Happens Next */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-purple-600" />
                <h2 className="text-2xl font-semibold text-gray-900">What Happens Next?</h2>
              </div>

              <div className="space-y-3">
                {[
                  {
                    number: 1,
                    text: "We'll analyze your feedback along with other responses",
                    icon: BarChart3,
                    color: "blue"
                  },
                  {
                    number: 2,
                    text: "Your insights will directly influence GraceFlow's features and design",
                    icon: Heart,
                    color: "purple"
                  },
                  {
                    number: 3,
                    text: "If you opted in for follow-up, we may contact you for additional input",
                    icon: Mail,
                    color: "green"
                  },
                  {
                    number: 4,
                    text: "Stay tuned for updates on GraceFlow's development!",
                    icon: Users,
                    color: "orange"
                  }
                ].map((step) => {
                  const Icon = step.icon;
                  return (
                    <Card key={step.number} className="border-l-4 border-l-purple-500">
                      <CardContent className="pt-4 pb-4">
                        <div className="flex items-start gap-3">
                          <Badge
                            variant="secondary"
                            className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center text-sm font-bold bg-${step.color}-100 text-${step.color}-700`}
                          >
                            {step.number}
                          </Badge>
                          <div className="flex items-start gap-2 flex-1 pt-1">
                            <Icon className={`w-4 h-4 text-${step.color}-600 flex-shrink-0 mt-0.5`} />
                            <p className="text-gray-700">{step.text}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Impact Section */}
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 space-y-3">
              <div className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-purple-600" />
                <h3 className="text-xl font-semibold text-gray-900">Your Impact</h3>
              </div>
              <p className="text-gray-700 leading-relaxed">
                By participating in this survey, you're helping us create a tool that will
                serve church communities better. Your voice matters in building features that
                truly address the needs of church organizers, volunteers, and members.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <Button
                className="flex-1 gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                onClick={() => navigate('/')}
              >
                <Home className="w-4 h-4" />
                Return to Home
              </Button>
              <Button
                variant="outline"
                className="flex-1 gap-2"
                onClick={() => navigate('/admin')}
              >
                <BarChart3 className="w-4 h-4" />
                View Responses (Admin)
              </Button>
            </div>
          </CardContent>

          <CardFooter className="flex flex-col items-center space-y-2 pt-6 border-t">
            <p className="text-sm text-gray-600">Have questions or want to learn more about GraceFlow?</p>
            <Badge variant="outline" className="text-xs">
              Contact the GraceFlow Team
            </Badge>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

export default ThankYouPage;
