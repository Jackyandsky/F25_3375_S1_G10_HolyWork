import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Clock, FileText, Lock, CheckCircle, Church, Users, Star } from 'lucide-react';

function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <Card className="border-purple-200 shadow-xl">
          <CardHeader className="text-center space-y-4 pb-8">
            <div className="flex justify-center">
              <Badge variant="secondary" className="text-lg px-4 py-2 bg-purple-100 text-purple-700 hover:bg-purple-200">
                GraceFlow Survey
              </Badge>
            </div>
            <CardTitle className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              GraceFlow
            </CardTitle>
            <CardDescription className="text-lg text-gray-700">
              Serving Together, Flowing in Grace Across Communities
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-8">
            {/* Introduction */}
            <div className="space-y-4">
              <h2 className="text-2xl font-semibold text-gray-900">Welcome to the GraceFlow Survey</h2>
              <p className="text-gray-600 leading-relaxed">
                We're building GraceFlow - a modern app to help churches manage volunteers,
                organize worship services, and connect communities across congregations.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Your feedback is invaluable! This survey will help us understand your needs
                and design features that truly serve your church community.
              </p>
            </div>

            {/* What to Expect */}
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-gray-900">What to Expect</h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <Card className="border-purple-100">
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-3">
                      <Clock className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-gray-900">10-15 minutes</p>
                        <p className="text-sm text-gray-600">Quick and easy to complete</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-3">
                      <FileText className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-gray-900">6 Sections</p>
                        <p className="text-sm text-gray-600">Demographics, tech usage, features</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-3">
                      <Lock className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-gray-900">Private & Confidential</p>
                        <p className="text-sm text-gray-600">Use an alias if you prefer</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-gray-900">Make an Impact</p>
                        <p className="text-sm text-gray-600">Help us build better features</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Target Audience */}
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-gray-900">We're Looking For Feedback From:</h3>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <Card className="border-blue-100 bg-blue-50/50">
                  <CardContent className="pt-6 text-center">
                    <Church className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                    <h4 className="font-semibold text-gray-900 mb-1">Church Leaders</h4>
                    <p className="text-sm text-gray-600">Priests, Pastors, Organizers</p>
                  </CardContent>
                </Card>

                <Card className="border-green-100 bg-green-50/50">
                  <CardContent className="pt-6 text-center">
                    <Users className="w-8 h-8 text-green-600 mx-auto mb-2" />
                    <h4 className="font-semibold text-gray-900 mb-1">Volunteers</h4>
                    <p className="text-sm text-gray-600">Music, Setup, Hospitality, etc.</p>
                  </CardContent>
                </Card>

                <Card className="border-purple-100 bg-purple-50/50">
                  <CardContent className="pt-6 text-center">
                    <Users className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                    <h4 className="font-semibold text-gray-900 mb-1">Church Members</h4>
                    <p className="text-sm text-gray-600">Regular attendees</p>
                  </CardContent>
                </Card>

                <Card className="border-orange-100 bg-orange-50/50">
                  <CardContent className="pt-6 text-center">
                    <Star className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                    <h4 className="font-semibold text-gray-900 mb-1">Young Adults</h4>
                    <p className="text-sm text-gray-600">Ages 18-35</p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Call to Action */}
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 text-center space-y-4">
              <Button
                size="lg"
                className="w-full sm:w-auto text-lg px-8 py-6 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                onClick={() => navigate('/survey')}
              >
                Start Survey →
              </Button>
              <p className="text-sm text-gray-600 max-w-2xl mx-auto">
                By clicking "Start Survey", you consent to participate in this research study
                to improve church management tools.
              </p>
            </div>
          </CardContent>

          <CardFooter className="flex flex-col items-center space-y-2 pt-6 border-t">
            <p className="text-sm text-gray-600">Questions? Contact the GraceFlow team</p>
            <Badge variant="outline" className="text-xs">
              CSIS 3375 - UX Web Design | Fall 2025
            </Badge>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

export default LandingPage;
