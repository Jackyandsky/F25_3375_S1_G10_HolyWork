import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import surveyService from '../api/surveyService';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Progress } from '../components/ui/progress';
import {
  BarChart3,
  Home,
  RefreshCw,
  Users,
  Calendar,
  Church,
  TrendingUp,
  Star,
  Loader2
} from 'lucide-react';

function AdminDashboard() {
  const navigate = useNavigate();
  const [surveys, setSurveys] = useState([]);
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [surveysData, statsData] = await Promise.all([
        surveyService.getAllSurveys(),
        surveyService.getStatistics(),
      ]);
      setSurveys(surveysData.data || []);
      setStatistics(statsData.data || null);
      setLoading(false);
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to load survey data');
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <Card className="border-blue-200">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-12 h-12 text-blue-600 animate-spin mb-4" />
              <p className="text-gray-600">Loading survey data...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <Card className="border-blue-200 shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-2xl">Survey Responses Dashboard</CardTitle>
                  <CardDescription>View and analyze collected survey data</CardDescription>
                </div>
              </div>
              <Button variant="outline" onClick={() => navigate('/')} className="gap-2">
                <Home className="w-4 h-4" />
                Back to Home
              </Button>
            </div>
          </CardHeader>
        </Card>

        {/* Error Alert */}
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Statistics Summary */}
        {statistics && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Responses</p>
                    <p className="text-3xl font-bold text-blue-600">
                      {statistics.totalResponses || 0}
                    </p>
                  </div>
                  <Users className="w-10 h-10 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-white">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Different Roles</p>
                    <p className="text-3xl font-bold text-purple-600">
                      {statistics.byRole?.length || 0}
                    </p>
                  </div>
                  <Church className="w-10 h-10 text-purple-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-green-200 bg-gradient-to-br from-green-50 to-white">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Age Groups</p>
                    <p className="text-3xl font-bold text-green-600">
                      {statistics.byAgeRange?.length || 0}
                    </p>
                  </div>
                  <TrendingUp className="w-10 h-10 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-orange-200 bg-gradient-to-br from-orange-50 to-white">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Church Sizes</p>
                    <p className="text-3xl font-bold text-orange-600">
                      {statistics.byChurchScale?.length || 0}
                    </p>
                  </div>
                  <Church className="w-10 h-10 text-orange-400" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Responses by Role */}
        {statistics?.byRole && statistics.byRole.length > 0 && (
          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                Responses by Role
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {statistics.byRole.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium text-gray-700">{item.role || 'Unknown'}</span>
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                      {item.count} {item.count === 1 ? 'response' : 'responses'}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Average Feature Ratings */}
        {statistics?.averageFeatureRatings && (
          <Card className="border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-blue-600" />
                Average Feature Ratings
              </CardTitle>
              <CardDescription>How users rated different GraceFlow features (out of 5)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(statistics.averageFeatureRatings).map(([key, value]) => {
                  const percentage = (value / 5) * 100;
                  const featureName = key
                    .replace(/avg_|_/g, ' ')
                    .replace(/\b\w/g, l => l.toUpperCase());

                  return (
                    <div key={key} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium text-gray-700">{featureName}</span>
                        <span className="font-bold text-blue-600">{value?.toFixed(1) || 0}</span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* All Responses Table */}
        <Card className="border-gray-200">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-gray-600" />
                  All Survey Responses
                </CardTitle>
                <CardDescription>
                  {surveys.length} {surveys.length === 1 ? 'response' : 'responses'} collected
                </CardDescription>
              </div>
              <Button onClick={fetchData} variant="outline" size="sm" className="gap-2">
                <RefreshCw className="w-4 h-4" />
                Refresh
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {surveys.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600 font-medium">No survey responses yet</p>
                <p className="text-gray-500 text-sm mt-2">Share the survey to start collecting data!</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        ID
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Age Range
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Role
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Church
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {surveys.map((survey) => (
                      <tr key={survey.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {survey.id}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-700">
                          {survey.name || 'Anonymous'}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-700">
                          <Badge variant="outline">{survey.age_range || 'N/A'}</Badge>
                        </td>
                        <td className="px-4 py-4 text-sm text-gray-700">
                          {survey.role || 'N/A'}
                        </td>
                        <td className="px-4 py-4 text-sm text-gray-700">
                          {survey.church_name || 'N/A'}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(survey.created_at).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default AdminDashboard;
