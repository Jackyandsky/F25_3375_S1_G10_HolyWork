# GraceFlow Survey Frontend

React frontend for the GraceFlow Requirements Gathering Survey application.

## 🚀 Quick Start

### Install Dependencies

```bash
npm install
```

### Start Development Server

```bash
npm start
```

Application runs at: **http://localhost:3000**

Make sure the backend server is running at **http://localhost:5000**

## 📦 Dependencies

- **react** - UI library
- **react-router-dom** - Routing
- **axios** - HTTP client
- **react-scripts** - Create React App scripts

## 📁 Project Structure

```
src/
├── api/
│   ├── config.js           # API configuration
│   └── surveyService.js    # API service functions
├── components/
│   └── survey/             # Survey step components
│       ├── Step1Demographics.js
│       ├── Step2ChurchInfo.js
│       ├── Step3CurrentPractices.js
│       ├── Step4Technology.js
│       ├── Step5FeatureRatings.js
│       └── Step6OpenResponses.js
├── pages/
│   ├── LandingPage.js      # Welcome/intro page
│   ├── SurveyPage.js       # Multi-step survey form
│   ├── ThankYouPage.js     # Submission confirmation
│   └── AdminDashboard.js   # View responses (admin)
├── App.js                  # Main app component with routing
├── App.css                 # Global styles
├── index.js                # App entry point
└── index.css               # Base styles
```

## 🎨 Pages

### 1. Landing Page (`/`)
- Welcome message
- Survey information
- Target audience
- Start survey button

### 2. Survey Page (`/survey`)
- Multi-step form (6 steps)
- Progress indicator
- Navigation between steps
- Form validation

**Steps:**
1. Demographics (name, age, role, etc.)
2. Church Information (name, size, location)
3. Current Practices (scheduling methods, volunteer teams)
4. Technology Usage (smartphone type, app comfort)
5. Feature Ratings (9 features rated 1-5)
6. Open Responses (feedback and suggestions)

### 3. Thank You Page (`/thank-you`)
- Submission confirmation
- Next steps information
- Return home option

### 4. Admin Dashboard (`/admin`)
- View all survey responses
- Statistics and charts
- Export data options

## 🔧 Configuration

### Environment Variables

Create `.env` file in the `front` directory:

```env
REACT_APP_API_URL=http://localhost:5000/api
```

## 🎨 Customization

### Colors

The app uses a purple gradient theme. To customize colors, edit `App.css` and component CSS files:

```css
/* Primary gradient */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Update to your brand colors */
background: linear-gradient(135deg, #your-color-1 0%, #your-color-2 100%);
```

### Typography

Font family is defined in `index.css`:

```css
font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', ...
```

## 📝 To Do - Complete Survey Components

The following survey step components need to be created in `src/components/survey/`:

### 1. Step1Demographics.js
Collects:
- Name/Alias
- Age & Age Range
- Gender
- Role
- Email (optional)
- Follow-up consent

### 2. Step2ChurchInfo.js
Collects:
- Church name
- Church type
- Church scale
- Average worshipers
- Location
- Years at church

### 3. Step3CurrentPractices.js
Collects:
- Scheduling methods (checkboxes)
- Volunteer teams (checkboxes)
- Volunteer frequency
- Current challenges (textarea)

### 4. Step4Technology.js
Collects:
- Smartphone type
- App comfort level (1-5 slider/buttons)
- Social media platforms (checkboxes)
- Current church apps (checkboxes)

### 5. Step5FeatureRatings.js
Collects:
- Feature ratings (1-5 for 9 features)
- Cross-church interest
- Youth engagement (if age 18-35)
- Bible study preferences

### 6. Step6OpenResponses.js
Collects:
- Top 3 features (textarea)
- Main concerns (textarea)
- Improvement ideas (textarea)
- Additional feedback (textarea)

## 🧪 Testing

```bash
npm test
```

## 🏗️ Build for Production

```bash
npm run build
```

Creates optimized production build in `build/` folder.

## 🚢 Deployment

### Option 1: Vercel
```bash
npm install -g vercel
vercel
```

### Option 2: Netlify
```bash
npm run build
# Drag and drop build/ folder to Netlify
```

### Option 3: GitHub Pages
```bash
npm install --save-dev gh-pages
# Add to package.json:
"homepage": "https://yourusername.github.io/graceflow-survey"
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d build"
}
npm run deploy
```

## 🔗 API Integration

The frontend connects to the backend API using axios. See `src/api/surveyService.js` for available methods:

- `submitSurvey(data)` - Submit survey response
- `getAllSurveys()` - Get all responses
- `getStatistics()` - Get aggregated stats
- `getYouthResponses()` - Get youth data

## 📊 Data Flow

1. User fills out survey (SurveyPage)
2. Data stored in React state
3. On submit, data sent to backend API
4. Backend validates and stores in SQLite
5. User redirected to Thank You page
6. Admin can view responses in dashboard

## 🛠️ Development Tips

### Hot Reload
Changes auto-reload during development (`npm start`)

### Component Development
Test components individually by importing in App.js

### Debugging
Use React DevTools browser extension

### State Management
Currently using React useState. For complex state, consider:
- Context API
- Redux
- Zustand

## 📱 Responsive Design

App is mobile-responsive with breakpoints at:
- Desktop: > 768px
- Tablet/Mobile: ≤ 768px

Test responsiveness using browser DevTools device toolbar.

## ✅ Checklist

Before launching:
- [ ] Create all 6 survey step components
- [ ] Add form validation
- [ ] Test on mobile devices
- [ ] Verify backend connection
- [ ] Test complete survey flow
- [ ] Add loading states
- [ ] Handle error cases
- [ ] Optimize for accessibility
- [ ] Cross-browser testing
- [ ] Performance optimization

## 🆘 Troubleshooting

### Cannot connect to backend
- Verify backend is running on port 5000
- Check CORS settings in backend
- Verify API_BASE_URL in config.js

### Build errors
- Delete `node_modules` and `package-lock.json`
- Run `npm install` again
- Clear npm cache: `npm cache clean --force`

### Routing issues
- Ensure BrowserRouter is properly configured
- Check route paths match navigation links

## 📄 License

MIT License - GraceFlow Team

## 👥 Team

- **Team Lead:** Menghua
- **Team Members:** Ryan, Menghua
- **Course:** CSIS 3375 - UX Web Design

---

**Version:** 1.0.0
**Last Updated:** October 2025
