# GraceFlow Survey Backend Server

Express.js backend server with SQLite database for the GraceFlow requirements gathering survey.

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Database Schema](#database-schema)
- [Installation](#installation)
- [API Endpoints](#api-endpoints)
- [Usage Examples](#usage-examples)
- [Project Structure](#project-structure)

## ✨ Features

- RESTful API for survey data collection
- SQLite database with comprehensive schema
- Support for multiple user types (Priests, Volunteers, Attendees, Youth)
- Feature ratings and cross-church collaboration data
- Statistics and analytics endpoints
- CORS enabled for React frontend integration

## 🛠 Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: SQLite3
- **Security**: Helmet, CORS
- **Environment**: dotenv

## 🗄 Database Schema

### Tables

1. **respondents** - Basic respondent information
2. **church_info** - Church/organization details
3. **current_practices** - Current scheduling and volunteer practices
4. **technology_usage** - Technology comfort and app usage
5. **cross_church_interest** - Cross-church collaboration interest
6. **feature_ratings** - Ratings for proposed app features (1-5 scale)
7. **youth_engagement** - Youth-specific engagement data (18-35 age group)
8. **bible_study** - Bible study participation and interests
9. **open_responses** - Open-ended survey responses
10. **role_specific_responses** - Role-based question responses

### Views

- **v_complete_responses** - Complete survey data joined view
- **v_youth_responses** - Youth-specific responses view

## 🚀 Installation

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Steps

1. **Navigate to server directory**
   ```bash
   cd F25_3375_S1_G9_GraceFlow/survey/server
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env
   # Edit .env if needed
   ```

4. **Initialize database**
   ```bash
   npm run init-db
   ```

5. **Start server**
   ```bash
   # Development mode with auto-reload
   npm run dev

   # Production mode
   npm start
   ```

Server will run on `http://localhost:5000` by default.

## 📡 API Endpoints

### Survey Endpoints

#### Create Survey Response
```http
POST /api/surveys
Content-Type: application/json

{
  "respondent": {
    "name": "John Doe",
    "age": 28,
    "ageRange": "26-35",
    "gender": "Male",
    "role": "Volunteer",
    "email": "john@example.com",
    "willingFollowup": true
  },
  "churchInfo": {
    "churchName": "Grace Community Church",
    "churchType": "Protestant",
    "churchScale": "Medium (50-200)",
    "averageWorshipers": 150,
    "location": "Vancouver, BC",
    "yearsAtChurch": 5
  },
  "currentPractices": {
    "schedulingMethods": ["Email", "WhatsApp/Text"],
    "volunteerTeams": ["Music", "Hospitality"],
    "volunteerFrequency": "Weekly",
    "currentChallenges": "Hard to coordinate schedules"
  },
  "technologyUsage": {
    "smartphoneType": "Android",
    "appComfortLevel": 4,
    "socialMediaPlatforms": ["Instagram", "TikTok"],
    "currentChurchApps": ["None"]
  },
  "crossChurchInterest": {
    "interested": true,
    "willingDistance": "<10 miles",
    "currentActivities": false
  },
  "featureRatings": {
    "automatedScheduling": 5,
    "crossChurchCalendar": 4,
    "serviceAgendaBuilder": 4,
    "digitalServiceBook": 5,
    "communityPrayerWall": 5,
    "gamification": 3,
    "socialSharing": 4,
    "bibleStudyTools": 5,
    "pushNotifications": 4
  },
  "youthEngagement": {
    "socialFeaturesInterest": 4,
    "gamificationAppeal": 3,
    "digitalSpiritualBalanceConcern": false,
    "preferredRecognition": "Public recognition"
  },
  "bibleStudy": {
    "currentParticipation": "Weekly",
    "digitalToolsInterest": true,
    "faithContentConcerns": "Want to keep it biblically sound"
  },
  "openResponses": {
    "topFeatures": "Prayer wall, scheduling, Bible study tools",
    "mainConcerns": "Privacy and staying focused during worship",
    "improvementIdeas": "Make volunteering easier and more connected",
    "additionalFeedback": "Great idea!"
  }
}
```

**Response:**
```json
{
  "success": true,
  "message": "Survey response created successfully",
  "data": {
    "respondentId": 1
  }
}
```

#### Get All Surveys
```http
GET /api/surveys
```

**Response:**
```json
{
  "success": true,
  "count": 10,
  "data": [...]
}
```

#### Get Survey by ID
```http
GET /api/surveys/:id
```

#### Get Youth Responses
```http
GET /api/surveys/youth
```

#### Get Statistics
```http
GET /api/surveys/statistics
```

**Response:**
```json
{
  "success": true,
  "data": {
    "totalResponses": 15,
    "byRole": [
      { "role": "Volunteer", "count": 8 },
      { "role": "Priest/Organizer", "count": 3 },
      { "role": "Regular Attendee", "count": 4 }
    ],
    "byAgeRange": [
      { "age_range": "18-25", "count": 5 },
      { "age_range": "26-35", "count": 7 },
      { "age_range": "36-50", "count": 3 }
    ],
    "byChurchScale": [
      { "church_scale": "Small (<50)", "count": 3 },
      { "church_scale": "Medium (50-200)", "count": 9 },
      { "church_scale": "Large (200-500)", "count": 3 }
    ],
    "averageFeatureRatings": {
      "avg_automated_scheduling": 4.2,
      "avg_cross_church_calendar": 3.8,
      "avg_service_agenda_builder": 4.0,
      "avg_digital_service_book": 4.5,
      "avg_community_prayer_wall": 4.7,
      "avg_gamification": 3.1,
      "avg_social_sharing": 3.5,
      "avg_bible_study_tools": 4.3,
      "avg_push_notifications": 4.1
    }
  }
}
```

#### Delete Survey
```http
DELETE /api/surveys/:id
```

## 💡 Usage Examples

### Using cURL

```bash
# Create a survey response
curl -X POST http://localhost:5000/api/surveys \
  -H "Content-Type: application/json" \
  -d @sample-survey.json

# Get all surveys
curl http://localhost:5000/api/surveys

# Get statistics
curl http://localhost:5000/api/surveys/statistics

# Get youth responses
curl http://localhost:5000/api/surveys/youth
```

### Using JavaScript (Fetch API)

```javascript
// Create survey response
const surveyData = {
  respondent: {
    name: "Jane Smith",
    age: 24,
    ageRange: "18-25",
    role: "Youth/Young Adult",
    // ... more fields
  },
  // ... other survey sections
};

fetch('http://localhost:5000/api/surveys', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify(surveyData)
})
  .then(response => response.json())
  .then(data => console.log(data));

// Get statistics
fetch('http://localhost:5000/api/surveys/statistics')
  .then(response => response.json())
  .then(stats => console.log(stats));
```

## 📁 Project Structure

```
server/
├── config/
│   ├── database.js          # Database connection singleton
│   └── schema.sql           # Database schema definition
├── controllers/
│   └── surveyController.js  # Survey request handlers
├── models/
│   └── Survey.js            # Survey model with CRUD operations
├── routes/
│   └── surveyRoutes.js      # API route definitions
├── scripts/
│   └── initDatabase.js      # Database initialization script
├── database/                # SQLite database files (created on init)
│   └── survey.db
├── .env                     # Environment variables
├── .env.example             # Environment template
├── .gitignore
├── package.json
├── server.js                # Main application entry point
└── README.md
```

## 🔧 Environment Variables

```env
PORT=5000                              # Server port
NODE_ENV=development                   # Environment (development/production)
DB_PATH=./database/survey.db          # SQLite database path
CORS_ORIGIN=http://localhost:3000     # Frontend URL for CORS
```

## 📊 Data Analysis

The database includes views for easy analysis:

### Complete Responses View
```sql
SELECT * FROM v_complete_responses;
```

### Youth Responses View (18-35 age group)
```sql
SELECT * FROM v_youth_responses;
```

### Custom Queries

```sql
-- Feature ratings by age group
SELECT r.age_range, AVG(fr.gamification) as avg_gamification
FROM respondents r
JOIN feature_ratings fr ON r.id = fr.respondent_id
GROUP BY r.age_range;

-- Cross-church interest by church size
SELECT ci.church_scale,
       SUM(CASE WHEN cci.interested = 1 THEN 1 ELSE 0 END) as interested_count,
       COUNT(*) as total_count
FROM church_info ci
JOIN cross_church_interest cci ON ci.respondent_id = cci.respondent_id
GROUP BY ci.church_scale;
```

## 🔒 Security

- Helmet.js for security headers
- CORS configured for specific origin
- SQL injection protection via parameterized queries
- Environment variables for sensitive configuration

## 🚦 Error Handling

All endpoints return consistent error responses:

```json
{
  "success": false,
  "message": "Error description",
  "error": "Detailed error message (in development mode)"
}
```

## 📝 License

MIT License - GraceFlow Team

## 👥 Contributing

1. Create feature branch
2. Make changes
3. Test thoroughly
4. Submit pull request

## 📞 Support

For questions or issues, contact the GraceFlow development team.
