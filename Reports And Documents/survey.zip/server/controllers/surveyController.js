const Survey = require('../models/Survey');

/**
 * Survey Controller - handles HTTP requests for surveys
 */
class SurveyController {
  /**
   * Create a new survey response
   * POST /api/surveys
   */
  static async create(req, res) {
    try {
      const surveyData = req.body;

      // Validate required fields
      if (!surveyData.respondent) {
        return res.status(400).json({
          success: false,
          message: 'Respondent information is required'
        });
      }

      // Create survey
      const respondentId = await Survey.create(surveyData);

      res.status(201).json({
        success: true,
        message: 'Survey response created successfully',
        data: { respondentId }
      });
    } catch (error) {
      console.error('Error creating survey:', error);
      res.status(500).json({
        success: false,
        message: 'Error creating survey response',
        error: error.message
      });
    }
  }

  /**
   * Get all survey responses
   * GET /api/surveys
   */
  static async getAll(req, res) {
    try {
      const surveys = await Survey.getAll();

      res.json({
        success: true,
        count: surveys.length,
        data: surveys
      });
    } catch (error) {
      console.error('Error fetching surveys:', error);
      res.status(500).json({
        success: false,
        message: 'Error fetching survey responses',
        error: error.message
      });
    }
  }

  /**
   * Get survey response by ID
   * GET /api/surveys/:id
   */
  static async getById(req, res) {
    try {
      const { id } = req.params;
      const survey = await Survey.getById(id);

      if (!survey) {
        return res.status(404).json({
          success: false,
          message: 'Survey response not found'
        });
      }

      res.json({
        success: true,
        data: survey
      });
    } catch (error) {
      console.error('Error fetching survey:', error);
      res.status(500).json({
        success: false,
        message: 'Error fetching survey response',
        error: error.message
      });
    }
  }

  /**
   * Get youth responses
   * GET /api/surveys/youth
   */
  static async getYouthResponses(req, res) {
    try {
      const youthResponses = await Survey.getYouthResponses();

      res.json({
        success: true,
        count: youthResponses.length,
        data: youthResponses
      });
    } catch (error) {
      console.error('Error fetching youth responses:', error);
      res.status(500).json({
        success: false,
        message: 'Error fetching youth responses',
        error: error.message
      });
    }
  }

  /**
   * Get survey statistics
   * GET /api/surveys/statistics
   */
  static async getStatistics(req, res) {
    try {
      const stats = await Survey.getStatistics();

      res.json({
        success: true,
        data: stats
      });
    } catch (error) {
      console.error('Error fetching statistics:', error);
      res.status(500).json({
        success: false,
        message: 'Error fetching statistics',
        error: error.message
      });
    }
  }

  /**
   * Delete survey response
   * DELETE /api/surveys/:id
   */
  static async delete(req, res) {
    try {
      const { id } = req.params;
      await Survey.delete(id);

      res.json({
        success: true,
        message: 'Survey response deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting survey:', error);
      res.status(500).json({
        success: false,
        message: 'Error deleting survey response',
        error: error.message
      });
    }
  }
}

module.exports = SurveyController;
