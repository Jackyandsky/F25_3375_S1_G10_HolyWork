const fs = require('fs');
const path = require('path');
const db = require('../config/database');

/**
 * Initialize the database with schema
 */
async function initDatabase() {
  try {
    console.log('Initializing database...');

    // Create database directory if it doesn't exist
    const dbDir = path.join(__dirname, '../database');
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
      console.log('Created database directory');
    }

    // Connect to database
    await db.connect();

    // Read schema file
    const schemaPath = path.join(__dirname, '../config/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');

    // Remove comment lines and inline comments
    const cleanedSchema = schema
      .split('\n')
      .map(line => {
        // Remove inline comments
        const commentIndex = line.indexOf('--');
        if (commentIndex !== -1) {
          return line.substring(0, commentIndex);
        }
        return line;
      })
      .filter(line => line.trim().length > 0)
      .join('\n');

    // Split schema into individual statements
    const statements = cleanedSchema
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0);

    // Execute each statement
    for (const statement of statements) {
      try {
        await db.run(statement);
      } catch (err) {
        console.error('Error executing statement:', statement.substring(0, 100));
        console.error(err.message);
      }
    }

    console.log('Database initialized successfully!');
    console.log('Tables created:');
    console.log('  - respondents');
    console.log('  - church_info');
    console.log('  - current_practices');
    console.log('  - technology_usage');
    console.log('  - cross_church_interest');
    console.log('  - feature_ratings');
    console.log('  - youth_engagement');
    console.log('  - bible_study');
    console.log('  - open_responses');
    console.log('  - role_specific_responses');
    console.log('\nViews created:');
    console.log('  - v_complete_responses');
    console.log('  - v_youth_responses');

    // Close database connection
    await db.close();
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
}

// Run initialization
if (require.main === module) {
  initDatabase();
}

module.exports = initDatabase;
