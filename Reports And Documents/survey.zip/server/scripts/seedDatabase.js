const fs = require('fs');
const path = require('path');
const db = require('../config/database');
const Survey = require('../models/Survey');

/**
 * Seed database with sample data for testing
 */
async function seedDatabase() {
  try {
    console.log('Seeding database with sample data...');

    // Connect to database
    await db.connect();

    // Load sample survey data
    const sampleDataPath = path.join(__dirname, '../sample-survey.json');
    const sampleData = JSON.parse(fs.readFileSync(sampleDataPath, 'utf8'));

    // Create sample survey
    const respondentId = await Survey.create(sampleData);
    console.log(`✓ Created sample survey with respondent ID: ${respondentId}`);

    // Create additional sample data with variations
    const sampleData2 = {
      respondent: {
        name: "Michael Chen",
        age: 45,
        ageRange: "36-50",
        gender: "Male",
        role: "Priest/Organizer",
        email: "m.chen@church.org",
        willingFollowup: true
      },
      churchInfo: {
        churchName: "St. Paul's Community Church",
        churchType: "Protestant",
        churchScale: "Large (200-500)",
        averageWorshipers: 350,
        location: "Burnaby, BC",
        yearsAtChurch: 12
      },
      currentPractices: {
        schedulingMethods: ["Email", "Phone calls", "Paper sign-up"],
        volunteerTeams: ["Set-up", "Clean-up", "Sanctuary Guild"],
        volunteerFrequency: "Weekly",
        currentChallenges: "Managing volunteers across multiple services and keeping everyone informed of changes."
      },
      technologyUsage: {
        smartphoneType: "iOS",
        appComfortLevel: 3,
        socialMediaPlatforms: ["Facebook"],
        currentChurchApps: ["Planning Center"]
      },
      crossChurchInterest: {
        interested: true,
        willingDistance: "<5 miles",
        currentActivities: true,
        activitiesDescription: "We occasionally share resources with nearby churches for special events."
      },
      featureRatings: {
        automatedScheduling: 5,
        crossChurchCalendar: 5,
        serviceAgendaBuilder: 5,
        digitalServiceBook: 4,
        communityPrayerWall: 4,
        gamification: 2,
        socialSharing: 3,
        bibleStudyTools: 4,
        pushNotifications: 5
      },
      bibleStudy: {
        currentParticipation: "Weekly",
        digitalToolsInterest: true,
        faithContentConcerns: "Need to ensure theological accuracy and alignment with our denomination's teachings."
      },
      openResponses: {
        topFeatures: "Service agenda builder, automated scheduling, cross-church calendar for resource sharing",
        mainConcerns: "Data privacy, ease of use for older congregation members, maintaining personal connection",
        improvementIdeas: "Would greatly reduce administrative burden and help us collaborate better with neighboring churches",
        additionalFeedback: "Looking forward to seeing this come to life. Our church community would benefit greatly."
      }
    };

    const respondentId2 = await Survey.create(sampleData2);
    console.log(`✓ Created sample survey with respondent ID: ${respondentId2}`);

    // Youth sample
    const sampleData3 = {
      respondent: {
        name: "Emma Williams",
        age: 22,
        ageRange: "18-25",
        gender: "Female",
        role: "Youth/Young Adult",
        email: "emma.w@email.com",
        willingFollowup: true
      },
      churchInfo: {
        churchName: "New Life Church",
        churchType: "Non-denominational",
        churchScale: "Small (<50)",
        averageWorshipers: 45,
        location: "Richmond, BC",
        yearsAtChurch: 3
      },
      currentPractices: {
        schedulingMethods: ["WhatsApp/Text"],
        volunteerTeams: ["Kids Church"],
        volunteerFrequency: "Bi-weekly",
        currentChallenges: "Hard to know when I'm needed and remembering to show up on time."
      },
      technologyUsage: {
        smartphoneType: "iOS",
        appComfortLevel: 5,
        socialMediaPlatforms: ["Instagram", "TikTok"],
        currentChurchApps: ["None"]
      },
      crossChurchInterest: {
        interested: true,
        willingDistance: "<20 miles",
        currentActivities: false
      },
      featureRatings: {
        automatedScheduling: 5,
        crossChurchCalendar: 5,
        serviceAgendaBuilder: 3,
        digitalServiceBook: 5,
        communityPrayerWall: 5,
        gamification: 5,
        socialSharing: 5,
        bibleStudyTools: 5,
        pushNotifications: 5
      },
      youthEngagement: {
        socialFeaturesInterest: 5,
        gamificationAppeal: 5,
        digitalSpiritualBalanceConcern: true,
        balanceExplanation: "I worry about being on my phone during worship, but if it helps me engage more, I think it's worth it.",
        preferredRecognition: "Badges/points"
      },
      bibleStudy: {
        currentParticipation: "Occasionally",
        digitalToolsInterest: true,
        faithContentConcerns: "Want to make sure it's accessible for beginners but also deep enough to grow in faith."
      },
      openResponses: {
        topFeatures: "Social sharing, gamification with streaks, prayer wall where I can support others",
        mainConcerns: "Making sure it doesn't feel too corporate or lose the personal touch of church community",
        improvementIdeas: "Would make me more engaged and help me connect with other young Christians across different churches",
        additionalFeedback: "Love the idea! This is exactly what our generation needs to stay connected to church."
      }
    };

    const respondentId3 = await Survey.create(sampleData3);
    console.log(`✓ Created sample survey with respondent ID: ${respondentId3}`);

    console.log('\n✅ Database seeded successfully!');
    console.log(`   Total sample responses: 3`);

    // Close database connection
    await db.close();
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
}

// Run seeding
if (require.main === module) {
  seedDatabase();
}

module.exports = seedDatabase;
