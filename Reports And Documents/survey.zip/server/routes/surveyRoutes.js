const express = require('express');
const router = express.Router();
const SurveyController = require('../controllers/surveyController');

/**
 * Survey Routes
 */

// Get statistics (must be before /:id route)
router.get('/statistics', SurveyController.getStatistics);

// Get youth responses (must be before /:id route)
router.get('/youth', SurveyController.getYouthResponses);

// Create new survey response
router.post('/', SurveyController.create);

// Get all survey responses
router.get('/', SurveyController.getAll);

// Get survey response by ID
router.get('/:id', SurveyController.getById);

// Delete survey response
router.delete('/:id', SurveyController.delete);

module.exports = router;
