const db = require('../config/database');

/**
 * Survey Model - handles all survey-related database operations
 */
class Survey {
  /**
   * Create a new survey response
   * @param {Object} surveyData - Complete survey data
   * @returns {Promise<number>} - Respondent ID
   */
  static async create(surveyData) {
    try {
      // Start transaction by inserting respondent first
      const respondent = await this.createRespondent(surveyData.respondent);
      const respondentId = respondent.id;

      // Insert related data
      if (surveyData.churchInfo) {
        await this.createChurchInfo(respondentId, surveyData.churchInfo);
      }

      if (surveyData.currentPractices) {
        await this.createCurrentPractices(respondentId, surveyData.currentPractices);
      }

      if (surveyData.technologyUsage) {
        await this.createTechnologyUsage(respondentId, surveyData.technologyUsage);
      }

      if (surveyData.crossChurchInterest) {
        await this.createCrossChurchInterest(respondentId, surveyData.crossChurchInterest);
      }

      if (surveyData.featureRatings) {
        await this.createFeatureRatings(respondentId, surveyData.featureRatings);
      }

      if (surveyData.youthEngagement) {
        await this.createYouthEngagement(respondentId, surveyData.youthEngagement);
      }

      if (surveyData.bibleStudy) {
        await this.createBibleStudy(respondentId, surveyData.bibleStudy);
      }

      if (surveyData.openResponses) {
        await this.createOpenResponses(respondentId, surveyData.openResponses);
      }

      if (surveyData.roleSpecificResponses && surveyData.roleSpecificResponses.length > 0) {
        await this.createRoleSpecificResponses(respondentId, surveyData.roleSpecificResponses);
      }

      return respondentId;
    } catch (error) {
      console.error('Error creating survey:', error);
      throw error;
    }
  }

  /**
   * Create respondent record
   */
  static async createRespondent(data) {
    const sql = `
      INSERT INTO respondents (name, age, age_range, gender, role, email, willing_followup)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    const params = [
      data.name || null,
      data.age || null,
      data.ageRange || null,
      data.gender || null,
      data.role || null,
      data.email || null,
      data.willingFollowup ? 1 : 0
    ];
    return await db.run(sql, params);
  }

  /**
   * Create church info record
   */
  static async createChurchInfo(respondentId, data) {
    const sql = `
      INSERT INTO church_info (respondent_id, church_name, church_type, church_scale,
                               average_worshipers, location, years_at_church)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    const params = [
      respondentId,
      data.churchName || null,
      data.churchType || null,
      data.churchScale || null,
      data.averageWorshipers || null,
      data.location || null,
      data.yearsAtChurch || null
    ];
    return await db.run(sql, params);
  }

  /**
   * Create current practices record
   */
  static async createCurrentPractices(respondentId, data) {
    const sql = `
      INSERT INTO current_practices (respondent_id, scheduling_methods, volunteer_teams,
                                     volunteer_frequency, current_challenges)
      VALUES (?, ?, ?, ?, ?)
    `;
    const params = [
      respondentId,
      JSON.stringify(data.schedulingMethods || []),
      JSON.stringify(data.volunteerTeams || []),
      data.volunteerFrequency || null,
      data.currentChallenges || null
    ];
    return await db.run(sql, params);
  }

  /**
   * Create technology usage record
   */
  static async createTechnologyUsage(respondentId, data) {
    const sql = `
      INSERT INTO technology_usage (respondent_id, smartphone_type, app_comfort_level,
                                    social_media_platforms, current_church_apps)
      VALUES (?, ?, ?, ?, ?)
    `;
    const params = [
      respondentId,
      data.smartphoneType || null,
      data.appComfortLevel || null,
      JSON.stringify(data.socialMediaPlatforms || []),
      JSON.stringify(data.currentChurchApps || [])
    ];
    return await db.run(sql, params);
  }

  /**
   * Create cross-church interest record
   */
  static async createCrossChurchInterest(respondentId, data) {
    const sql = `
      INSERT INTO cross_church_interest (respondent_id, interested, willing_distance,
                                         current_activities, activities_description)
      VALUES (?, ?, ?, ?, ?)
    `;
    const params = [
      respondentId,
      data.interested ? 1 : 0,
      data.willingDistance || null,
      data.currentActivities ? 1 : 0,
      data.activitiesDescription || null
    ];
    return await db.run(sql, params);
  }

  /**
   * Create feature ratings record
   */
  static async createFeatureRatings(respondentId, data) {
    const sql = `
      INSERT INTO feature_ratings (respondent_id, automated_scheduling, cross_church_calendar,
                                   service_agenda_builder, digital_service_book, community_prayer_wall,
                                   gamification, social_sharing, bible_study_tools, push_notifications)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const params = [
      respondentId,
      data.automatedScheduling || null,
      data.crossChurchCalendar || null,
      data.serviceAgendaBuilder || null,
      data.digitalServiceBook || null,
      data.communityPrayerWall || null,
      data.gamification || null,
      data.socialSharing || null,
      data.bibleStudyTools || null,
      data.pushNotifications || null
    ];
    return await db.run(sql, params);
  }

  /**
   * Create youth engagement record
   */
  static async createYouthEngagement(respondentId, data) {
    const sql = `
      INSERT INTO youth_engagement (respondent_id, social_features_interest, gamification_appeal,
                                    digital_spiritual_balance_concern, balance_explanation, preferred_recognition)
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    const params = [
      respondentId,
      data.socialFeaturesInterest || null,
      data.gamificationAppeal || null,
      data.digitalSpiritualBalanceConcern ? 1 : 0,
      data.balanceExplanation || null,
      data.preferredRecognition || null
    ];
    return await db.run(sql, params);
  }

  /**
   * Create Bible study record
   */
  static async createBibleStudy(respondentId, data) {
    const sql = `
      INSERT INTO bible_study (respondent_id, current_participation, digital_tools_interest,
                               faith_content_concerns)
      VALUES (?, ?, ?, ?)
    `;
    const params = [
      respondentId,
      data.currentParticipation || null,
      data.digitalToolsInterest ? 1 : 0,
      data.faithContentConcerns || null
    ];
    return await db.run(sql, params);
  }

  /**
   * Create open responses record
   */
  static async createOpenResponses(respondentId, data) {
    const sql = `
      INSERT INTO open_responses (respondent_id, top_features, main_concerns,
                                  improvement_ideas, additional_feedback)
      VALUES (?, ?, ?, ?, ?)
    `;
    const params = [
      respondentId,
      data.topFeatures || null,
      data.mainConcerns || null,
      data.improvementIdeas || null,
      data.additionalFeedback || null
    ];
    return await db.run(sql, params);
  }

  /**
   * Create role-specific responses
   */
  static async createRoleSpecificResponses(respondentId, responses) {
    const sql = `
      INSERT INTO role_specific_responses (respondent_id, role_type, question, answer)
      VALUES (?, ?, ?, ?)
    `;

    for (const response of responses) {
      const params = [
        respondentId,
        response.roleType,
        response.question,
        response.answer
      ];
      await db.run(sql, params);
    }
  }

  /**
   * Get all survey responses
   */
  static async getAll() {
    const sql = 'SELECT * FROM v_complete_responses ORDER BY created_at DESC';
    return await db.all(sql);
  }

  /**
   * Get survey response by ID
   */
  static async getById(id) {
    const sql = 'SELECT * FROM v_complete_responses WHERE id = ?';
    return await db.get(sql, [id]);
  }

  /**
   * Get youth responses
   */
  static async getYouthResponses() {
    const sql = 'SELECT * FROM v_youth_responses ORDER BY created_at DESC';
    return await db.all(sql);
  }

  /**
   * Get statistics
   */
  static async getStatistics() {
    const stats = {};

    // Total responses
    const totalResult = await db.get('SELECT COUNT(*) as total FROM respondents');
    stats.totalResponses = totalResult.total;

    // Responses by role
    const roleResults = await db.all(`
      SELECT role, COUNT(*) as count
      FROM respondents
      GROUP BY role
    `);
    stats.byRole = roleResults;

    // Responses by age range
    const ageResults = await db.all(`
      SELECT age_range, COUNT(*) as count
      FROM respondents
      WHERE age_range IS NOT NULL
      GROUP BY age_range
    `);
    stats.byAgeRange = ageResults;

    // Responses by church scale
    const scaleResults = await db.all(`
      SELECT church_scale, COUNT(*) as count
      FROM church_info
      WHERE church_scale IS NOT NULL
      GROUP BY church_scale
    `);
    stats.byChurchScale = scaleResults;

    // Average feature ratings
    const avgRatings = await db.get(`
      SELECT
        AVG(automated_scheduling) as avg_automated_scheduling,
        AVG(cross_church_calendar) as avg_cross_church_calendar,
        AVG(service_agenda_builder) as avg_service_agenda_builder,
        AVG(digital_service_book) as avg_digital_service_book,
        AVG(community_prayer_wall) as avg_community_prayer_wall,
        AVG(gamification) as avg_gamification,
        AVG(social_sharing) as avg_social_sharing,
        AVG(bible_study_tools) as avg_bible_study_tools,
        AVG(push_notifications) as avg_push_notifications
      FROM feature_ratings
    `);
    stats.averageFeatureRatings = avgRatings;

    return stats;
  }

  /**
   * Delete survey response
   */
  static async delete(id) {
    const sql = 'DELETE FROM respondents WHERE id = ?';
    return await db.run(sql, [id]);
  }
}

module.exports = Survey;
