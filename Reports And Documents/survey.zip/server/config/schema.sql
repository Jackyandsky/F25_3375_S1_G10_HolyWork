-- GraceFlow Survey Database Schema
-- This schema stores responses from the requirements gathering survey

-- ============================================
-- 1. RESPONDENTS TABLE
-- ============================================
-- Stores basic information about survey respondents
CREATE TABLE IF NOT EXISTS respondents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(255),  -- Can be alias/nickname for privacy
    age INTEGER,
    age_range VARCHAR(20),  -- '18-25', '26-35', '36-50', '51-65', '65+'
    gender VARCHAR(50),  -- 'Male', 'Female', 'Non-binary', 'Prefer not to say'
    role VARCHAR(100),  -- 'Priest/Organizer', 'Volunteer', 'Regular Attendee', 'Youth/Young Adult'
    email VARCHAR(255),  -- Optional, for follow-up
    willing_followup BOOLEAN DEFAULT 0,  -- Willing to participate in future interviews
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 2. CHURCH INFORMATION TABLE
-- ============================================
-- Stores information about the respondent's church/organization
CREATE TABLE IF NOT EXISTS church_info (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    respondent_id INTEGER NOT NULL,
    church_name VARCHAR(255),
    church_type VARCHAR(100),  -- 'Protestant', 'Catholic', 'Non-denominational', 'Community Church', 'Other'
    church_scale VARCHAR(50),  -- 'Small (<50)', 'Medium (50-200)', 'Large (200-500)', 'Very Large (500+)'
    average_worshipers INTEGER,
    location VARCHAR(255),  -- City/region
    years_at_church INTEGER,  -- Years of experience at current church
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (respondent_id) REFERENCES respondents(id) ON DELETE CASCADE
);

-- ============================================
-- 3. CURRENT PRACTICES TABLE
-- ============================================
-- Stores information about current scheduling and volunteer practices
CREATE TABLE IF NOT EXISTS current_practices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    respondent_id INTEGER NOT NULL,
    scheduling_methods TEXT,  -- JSON array: ['Paper sign-up', 'Phone calls', 'Email', 'WhatsApp/Text', 'Other']
    volunteer_teams TEXT,  -- JSON array: ['Set-up', 'Clean-up', 'Music', 'Hospitality', 'Sanctuary Guild', 'Kids Church']
    volunteer_frequency VARCHAR(50),  -- 'Weekly', 'Bi-weekly', 'Monthly', 'Occasionally', 'Never'
    current_challenges TEXT,  -- Open-ended text
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (respondent_id) REFERENCES respondents(id) ON DELETE CASCADE
);

-- ============================================
-- 4. TECHNOLOGY USAGE TABLE
-- ============================================
-- Stores technology and app usage information
CREATE TABLE IF NOT EXISTS technology_usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    respondent_id INTEGER NOT NULL,
    smartphone_type VARCHAR(50),  -- 'Android', 'iOS', 'Both', 'None'
    app_comfort_level INTEGER,  -- Scale 1-5
    social_media_platforms TEXT,  -- JSON array: ['Instagram', 'TikTok', 'Facebook', 'None', 'Other']
    current_church_apps TEXT,  -- JSON array: ['Planning Center', 'Church Center', 'Subsplash', 'None', 'Other']
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (respondent_id) REFERENCES respondents(id) ON DELETE CASCADE
);

-- ============================================
-- 5. CROSS-CHURCH COLLABORATION TABLE
-- ============================================
-- Stores interest in cross-church volunteering
CREATE TABLE IF NOT EXISTS cross_church_interest (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    respondent_id INTEGER NOT NULL,
    interested BOOLEAN,  -- Interest in cross-church volunteering
    willing_distance VARCHAR(50),  -- 'Same church only', '<5 miles', '<10 miles', '<20 miles', 'Anywhere in region'
    current_activities BOOLEAN,  -- Currently participate in cross-church activities
    activities_description TEXT,  -- Description if yes
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (respondent_id) REFERENCES respondents(id) ON DELETE CASCADE
);

-- ============================================
-- 6. FEATURE RATINGS TABLE
-- ============================================
-- Stores ratings for proposed app features (1-5 scale)
CREATE TABLE IF NOT EXISTS feature_ratings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    respondent_id INTEGER NOT NULL,
    automated_scheduling INTEGER,  -- 1-5 rating
    cross_church_calendar INTEGER,
    service_agenda_builder INTEGER,
    digital_service_book INTEGER,
    community_prayer_wall INTEGER,
    gamification INTEGER,
    social_sharing INTEGER,
    bible_study_tools INTEGER,
    push_notifications INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (respondent_id) REFERENCES respondents(id) ON DELETE CASCADE,
    CHECK (automated_scheduling BETWEEN 1 AND 5),
    CHECK (cross_church_calendar BETWEEN 1 AND 5),
    CHECK (service_agenda_builder BETWEEN 1 AND 5),
    CHECK (digital_service_book BETWEEN 1 AND 5),
    CHECK (community_prayer_wall BETWEEN 1 AND 5),
    CHECK (gamification BETWEEN 1 AND 5),
    CHECK (social_sharing BETWEEN 1 AND 5),
    CHECK (bible_study_tools BETWEEN 1 AND 5),
    CHECK (push_notifications BETWEEN 1 AND 5)
);

-- ============================================
-- 7. YOUTH ENGAGEMENT TABLE (for 18-35 age group)
-- ============================================
-- Stores youth-specific engagement preferences
CREATE TABLE IF NOT EXISTS youth_engagement (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    respondent_id INTEGER NOT NULL,
    social_features_interest INTEGER,  -- 1-5 scale
    gamification_appeal INTEGER,  -- 1-5 scale
    digital_spiritual_balance_concern BOOLEAN,
    balance_explanation TEXT,
    preferred_recognition VARCHAR(100),  -- 'Public recognition', 'Private thank you', 'Badges/points', 'No preference'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (respondent_id) REFERENCES respondents(id) ON DELETE CASCADE
);

-- ============================================
-- 8. BIBLE STUDY TABLE
-- ============================================
-- Stores Bible study participation and interest
CREATE TABLE IF NOT EXISTS bible_study (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    respondent_id INTEGER NOT NULL,
    current_participation VARCHAR(50),  -- 'Weekly', 'Monthly', 'Occasionally', 'Never'
    digital_tools_interest BOOLEAN,
    faith_content_concerns TEXT,  -- Open-ended concerns
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (respondent_id) REFERENCES respondents(id) ON DELETE CASCADE
);

-- ============================================
-- 9. OPEN-ENDED RESPONSES TABLE
-- ============================================
-- Stores open-ended survey responses
CREATE TABLE IF NOT EXISTS open_responses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    respondent_id INTEGER NOT NULL,
    top_features TEXT,  -- Top 3 features wanted
    main_concerns TEXT,  -- Main concerns about church apps
    improvement_ideas TEXT,  -- How app would improve church experience
    additional_feedback TEXT,  -- Any other suggestions
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (respondent_id) REFERENCES respondents(id) ON DELETE CASCADE
);

-- ============================================
-- 10. ROLE-SPECIFIC RESPONSES TABLE
-- ============================================
-- Stores role-specific questions and answers
CREATE TABLE IF NOT EXISTS role_specific_responses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    respondent_id INTEGER NOT NULL,
    role_type VARCHAR(100),  -- 'Priest', 'Set-up Team', 'Music Team', etc.
    question TEXT,
    answer TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (respondent_id) REFERENCES respondents(id) ON DELETE CASCADE
);

-- ============================================
-- INDEXES for better query performance
-- ============================================
CREATE INDEX IF NOT EXISTS idx_respondents_role ON respondents(role);
CREATE INDEX IF NOT EXISTS idx_respondents_age_range ON respondents(age_range);
CREATE INDEX IF NOT EXISTS idx_respondents_created_at ON respondents(created_at);
CREATE INDEX IF NOT EXISTS idx_church_info_respondent ON church_info(respondent_id);
CREATE INDEX IF NOT EXISTS idx_church_info_scale ON church_info(church_scale);
CREATE INDEX IF NOT EXISTS idx_current_practices_respondent ON current_practices(respondent_id);
CREATE INDEX IF NOT EXISTS idx_technology_usage_respondent ON technology_usage(respondent_id);
CREATE INDEX IF NOT EXISTS idx_cross_church_respondent ON cross_church_interest(respondent_id);
CREATE INDEX IF NOT EXISTS idx_feature_ratings_respondent ON feature_ratings(respondent_id);
CREATE INDEX IF NOT EXISTS idx_youth_engagement_respondent ON youth_engagement(respondent_id);
CREATE INDEX IF NOT EXISTS idx_bible_study_respondent ON bible_study(respondent_id);
CREATE INDEX IF NOT EXISTS idx_open_responses_respondent ON open_responses(respondent_id);
CREATE INDEX IF NOT EXISTS idx_role_specific_respondent ON role_specific_responses(respondent_id);

-- ============================================
-- VIEWS for easier data analysis
-- ============================================

-- Complete survey response view
CREATE VIEW IF NOT EXISTS v_complete_responses AS
SELECT
    r.id,
    r.name,
    r.age,
    r.age_range,
    r.gender,
    r.role,
    r.email,
    r.willing_followup,
    ci.church_name,
    ci.church_type,
    ci.church_scale,
    ci.average_worshipers,
    ci.location,
    ci.years_at_church,
    cp.scheduling_methods,
    cp.volunteer_teams,
    cp.volunteer_frequency,
    cp.current_challenges,
    tu.smartphone_type,
    tu.app_comfort_level,
    tu.social_media_platforms,
    tu.current_church_apps,
    cci.interested as cross_church_interested,
    cci.willing_distance,
    fr.automated_scheduling,
    fr.cross_church_calendar,
    fr.service_agenda_builder,
    fr.digital_service_book,
    fr.community_prayer_wall,
    fr.gamification,
    fr.social_sharing,
    fr.bible_study_tools,
    fr.push_notifications,
    orr.top_features,
    orr.main_concerns,
    orr.improvement_ideas,
    orr.additional_feedback,
    r.created_at
FROM respondents r
LEFT JOIN church_info ci ON r.id = ci.respondent_id
LEFT JOIN current_practices cp ON r.id = cp.respondent_id
LEFT JOIN technology_usage tu ON r.id = tu.respondent_id
LEFT JOIN cross_church_interest cci ON r.id = cci.respondent_id
LEFT JOIN feature_ratings fr ON r.id = fr.respondent_id
LEFT JOIN open_responses orr ON r.id = orr.respondent_id;

-- Youth responses view
CREATE VIEW IF NOT EXISTS v_youth_responses AS
SELECT
    r.id,
    r.name,
    r.age,
    r.role,
    ye.social_features_interest,
    ye.gamification_appeal,
    ye.digital_spiritual_balance_concern,
    ye.preferred_recognition,
    bs.current_participation as bible_study_participation,
    bs.digital_tools_interest as bible_tools_interest,
    r.created_at
FROM respondents r
INNER JOIN youth_engagement ye ON r.id = ye.respondent_id
LEFT JOIN bible_study bs ON r.id = bs.respondent_id
WHERE r.age BETWEEN 18 AND 35 OR r.age_range IN ('18-25', '26-35');
